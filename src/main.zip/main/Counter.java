package main;


public class Counter extends Thread{
	private int input;
	private Singleton instance;
	private int counter;
	public Counter(int input) {
		instance = Singleton.getInstance();
		this.input = input;
		counter = 0;
	}

	@Override
	public void run() {
//		synchronized (instance.list) {

			while (counter < 10) {
				synchronized (instance.list) {
					instance.list.add(input);
					counter++;
					try {
						for (Integer i : instance.list) {
							System.out.println(i);
						}
						System.out.println("---------------");
					} catch (Exception e) {
						System.out.println(e);
						System.exit(0);
					}
				}
			}
//		}
	}
	
}
