package main;

import java.util.ArrayList;

import javafx.application.Application;
import javafx.stage.Stage;

public class Main extends Application{

	public Main() {
		Thread t1 = new Thread(new Runnable() {
			int count = 0;

			@Override
			public void run() {
				while (count < 100) {
					System.out.println("Thread 1 = " + count++);
				}
			}
		});
		
		Thread t2 = new Thread(new Runnable() {

			int count = 0;

			@Override
			public void run() {
				while (count < 100) {
					System.out.println("Thread 2 = " + count++);
				}
			}
			
		});
		
		t1.start();
		try {
			t1.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		t2.start();
		
		
//		Thread t1 = new Counter(1);
//		Thread t2 = new Counter(2);
//		
//		t1.start();
//		t2.start();
	}

	public static void main(String[] args) {
		new Main();
	}

	@Override
	public void start(Stage arg0) throws Exception {
		// TODO Auto-generated method stub
		
	}

}


class Singleton {
	private static Singleton instance;
	public ArrayList<Integer> list;
	
	private Singleton() {
		list = new ArrayList<>();
	}
	
	public static Singleton getInstance() {
		if (instance == null) {
			synchronized (Singleton.class) {
				if (instance == null) {
					instance = new Singleton();
				}
			}
		}
		return instance;
	}
	
}
